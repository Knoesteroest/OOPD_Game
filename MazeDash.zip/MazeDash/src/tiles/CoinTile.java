package tiles;

import me.main.Game;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.tile.Tile;
import nl.han.ica.oopg.tile.TileMap;
import nl.han.ica.oopg.tile.TileType;

public class CoinTile extends Tile {
    public CoinTile(Sprite sprite) {
        super(sprite);

    }
}
